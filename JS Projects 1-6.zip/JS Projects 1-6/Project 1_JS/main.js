/*
* Jean Laurore
* 3-16-20
* Code Excersice 01
*/

// Greetings
console.log("Hello Professor!");
console.log("----------------");

// Output solutions
console.log("\r\nMy name is Jean Laurore, I'm in Web Design/Dev. \r\nI want to become a developer because it my passion and I love coding. " +
                "\r\nI want to become the best at it and succeed.");

  // Goodbye
console.log("\r\nThe End!");