//Code exercise 02

console.log("****************************************");
console.log("**** Welcome to My Problem Analysis ****");
console.log("****************************************");

let userName = prompt("\r\nPlease type in your name");

//Say hello to the user
console.log("\r\nHello " + userName + ", welcome!")

//Prompt the user
let userAnimal = prompt("Enter an animal name:");

var userNumber = prompt("\r\nEnter a number:");

let userPro = prompt("\r\nPlease type a proffesion like lawyer, doctor or teacher, etc...");
let userChoice = prompt("\r\nPlease type son or daughter? Write one.");

//write a short story to the user
console.log("\r\nIn a world where " + userAnimal + " are stand-up comedians. \r\n" + userNumber + " " + userPro + " has no choice but " +
"to find another planet to colonise by killing his own " + userChoice +"\r\nAfter a long and drawn out battle, the " + userPro + " saves the day.");
//Ending with a thank you
console.log("\r\nThank You!");