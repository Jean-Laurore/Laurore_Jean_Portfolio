﻿using System;

namespace Laurore_Jean_CE01
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * Jean Laurore
             * Oct 28, 19
             * Code Excersice 01
             */

            // Greetings
            Console.WriteLine("Hello Professor!");
            Console.WriteLine("----------------");

            // Output solutions
            Console.WriteLine("\r\nMy name is Jean Laurore, I'm in Web Design/Dev. \r\nI want to become a developer because it my passion and I love coding. " +
                "\r\nI want to become the best at it and succeed.");

            // Goodbye
            Console.WriteLine("\r\nThe End!");
        }
    }
}
