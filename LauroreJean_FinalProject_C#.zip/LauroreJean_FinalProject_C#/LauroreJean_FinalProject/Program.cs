﻿using System;
// The purpose of this class is to only instantiate the assignment class.
namespace LauroreJean_FinalProject
{
    class Program
    {
        static void Main(string[] args)
        {
            //Instanting assignment class
            Assignment a = new Assignment();
        }
    }
}
